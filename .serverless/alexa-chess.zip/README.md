# Alexa Chess
Alexa Skill to play correspondence chess games using Lichess.org platform
